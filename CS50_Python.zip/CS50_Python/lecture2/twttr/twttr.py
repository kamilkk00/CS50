input = str(input("Input: ")).replace("a", "").replace("E","").replace("e", "").replace("I","").replace("i", "")
input = input.replace("O", "").replace("o","").replace("U", "").replace("u","")
print(f"output: {input}")
