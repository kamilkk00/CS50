one = input("What is the Answer to the Great Question of Life, the Universe, and Everything? ").lower().strip()
if one == "42":
    print("Yes")
elif one == "forty-two":
    print("Yes")
elif one == "forty two":
    print("Yes")
else:
    print("No")