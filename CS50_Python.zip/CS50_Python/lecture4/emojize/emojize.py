import emoji

x = input("Input: ")
print (emoji.emojize(f"Output: {x}", language='alias'))
