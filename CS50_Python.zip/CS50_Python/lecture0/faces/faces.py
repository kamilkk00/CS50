def main():
   faces = input ("text: ").replace(":(","🙁").replace(":)","\U0001F642")
   print(f"{faces}")
main()
