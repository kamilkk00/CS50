mniejsze = input("Jakie słowo chcesz przekazać ").lower()
print(f"oto twoje słowo: {mniejsze}")
