kropki = input("Word to dots: ").replace(" ","...")
print(f"{kropki}")
