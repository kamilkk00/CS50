m = int(input("m: "))
c = 300000000
e = m * c ** 2
print(f"e = {e}")
